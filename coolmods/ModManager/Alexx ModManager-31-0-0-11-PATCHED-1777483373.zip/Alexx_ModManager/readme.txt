hii hellooo haiii :3

This mod was entirely written by Alexx_ as BepInEx plugin.
For this mod to work, downloading BepInEx is essential.
Read "howtomod.txt" for info about BepInEx stuff.
Read "modstuff.txt" for mod info.

if you encounter any problems or bugs please contact me!

THIS MOD ONLY WORKS WITH STEAM VERSION OF THE GAME
PLEASE NOTE THAT THIS MOD DOES NOT WORK WITH ANY OTHER VERSION

written at 21.04.2026
by alexx_
discord: im_sowrizz
